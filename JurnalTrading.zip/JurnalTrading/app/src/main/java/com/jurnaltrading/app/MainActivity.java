package com.jurnaltrading.app;
import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 EditText capital,risk,sl,tp,pair,entry,note; TextView result,history; android.content.SharedPreferences pref;
 double d(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); pref=getSharedPreferences("trades",0); capital=findViewById(R.id.capital);risk=findViewById(R.id.risk);sl=findViewById(R.id.sl);tp=findViewById(R.id.tp);pair=findViewById(R.id.pair);entry=findViewById(R.id.entry);note=findViewById(R.id.note);result=findViewById(R.id.result);history=findViewById(R.id.history);load();
 findViewById(R.id.calc).setOnClickListener(v->{double s=d(sl),t=d(tp),r=d(risk),c=d(capital); if(s<=0||t<=0){result.setText("Isi SL dan TP terlebih dahulu.");return;} double rr=t/s,loss=c*r/100; result.setText(String.format(Locale.US,"RR = 1 : %.2f\nRisiko maksimum = Rp %,.0f\nReward target = Rp %,.0f",rr,loss,loss*rr));});
 findViewById(R.id.save).setOnClickListener(v->{String old=pref.getString("h","");String x=pair.getText().toString()+" | Entry: "+entry.getText().toString()+"\n"+note.getText().toString();pref.edit().putString("h",x+(old.isEmpty()?"":"\n\n")+old).apply();load(); pair.setText("");entry.setText("");note.setText(""); Toast.makeText(this,"Trade tersimpan",Toast.LENGTH_SHORT).show();}); }
 void load(){String h=pref.getString("h","");history.setText(h.isEmpty()?"Belum ada trade.":h);}
}
